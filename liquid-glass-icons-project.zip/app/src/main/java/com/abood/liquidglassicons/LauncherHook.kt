package com.abood.liquidglassicons

import android.graphics.Canvas
import android.view.View
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class LauncherHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != TARGET_LAUNCHER) return

        try {
            XposedHelpers.findAndHookMethod(
                "com.android.launcher3.BubbleTextView",
                lpparam.classLoader,
                "drawIcon",
                Canvas::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val iconView = param.thisObject as? View ?: return
                        val packageName = IconPackageResolver.resolve(iconView)
                        if (packageName == null || !GlassIconCatalog.isSupported(packageName)) {
                            GlassOverlayController.remove(iconView)
                            return
                        }

                        // Suppress only the stock icon draw. BubbleTextView.onDraw still draws
                        // its text, badges, and the rest of the normal launcher view.
                        GlassOverlayController.onIconDraw(iconView, packageName)
                        param.result = null
                    }
                }
            )
            XposedBridge.log("LGIcons: hooked BubbleTextView.drawIcon(Canvas)")
        } catch (t: Throwable) {
            XposedBridge.log("LGIcons: failed to hook drawIcon: $t")
        }
    }

    companion object {
        private const val TARGET_LAUNCHER = "com.android.launcher"
    }
}
