package com.abood.liquidglassicons

internal object GlassIconCatalog {
    // Package aliases cover the common OPPO/ColorOS and Google variants.
    private val glyphs = mapOf(
        "com.android.contacts" to Glyph.PHONE,
        "com.google.android.dialer" to Glyph.PHONE,
        "com.android.mms" to Glyph.MESSAGES,
        "com.google.android.apps.messaging" to Glyph.MESSAGES,
        "com.android.chrome" to Glyph.CHROME,
        "com.oplus.camera" to Glyph.CAMERA,
        "com.android.camera" to Glyph.CAMERA,
        "com.android.settings" to Glyph.SETTINGS,
        "com.coloros.gallery3d" to Glyph.GALLERY,
        "com.google.android.apps.photos" to Glyph.GALLERY,
        "com.coloros.calculator" to Glyph.CALCULATOR,
        "com.oplus.calculator" to Glyph.CALCULATOR,
        "com.google.android.calculator" to Glyph.CALCULATOR,
        "com.coloros.weather2" to Glyph.WEATHER,
        "com.oplus.weather" to Glyph.WEATHER,
        "com.google.android.youtube" to Glyph.YOUTUBE,
        "com.whatsapp" to Glyph.WHATSAPP,
        "com.spotify.music" to Glyph.SPOTIFY,
        "org.telegram.messenger" to Glyph.TELEGRAM
    )

    fun isSupported(packageName: String) = glyphs.containsKey(packageName)
    fun glyph(packageName: String) = glyphs[packageName] ?: Glyph.DEFAULT
}

internal enum class Glyph {
    PHONE, MESSAGES, CHROME, CAMERA, SETTINGS, GALLERY,
    CALCULATOR, WEATHER, YOUTUBE, WHATSAPP, SPOTIFY, TELEGRAM, DEFAULT
}
