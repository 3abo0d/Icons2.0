package com.abood.liquidglassicons

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import android.view.Gravity
import android.graphics.Typeface
import android.graphics.Color
import android.view.ViewGroup
import android.widget.LinearLayout

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(18, 20, 25))
        }
        root.addView(TextView(this).apply {
            text = "Liquid Glass Icons"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }, ViewGroup.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "This is an LSPosed module for the stock OPPO Launcher.\\n\\n" +
                "Enable it for com.android.launcher in LSPosed, then reboot or force-stop the launcher.\\n\\n" +
                "The first build targets 12 selected apps. The original launcher and labels remain in place; " +
                "the stock icon artwork is replaced by individually positioned live glass glyphs.\\n\\n" +
                "If an icon is missing, its package name may differ on your firmware. Check the module log tag: LGIcons."
            textSize = 15f
            setTextColor(Color.rgb(220, 225, 235))
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }, ViewGroup.LayoutParams(-1, -2))
        setContentView(root)
    }
}
