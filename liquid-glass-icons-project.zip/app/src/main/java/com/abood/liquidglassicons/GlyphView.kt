package com.abood.liquidglassicons

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.min

/**
 * Original vector glyph artwork. These are deliberately drawn as paths and strokes,
 * not raster icon-pack images or opaque icon plates.
 */
internal class GlyphView(context: Context, private val glyph: Glyph) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 6.5f
        color = Color.WHITE
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 6f
    }
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val save = canvas.save()
        val side = min(width, height).toFloat()
        canvas.translate((width - side) / 2f, (height - side) / 2f)
        canvas.scale(side / 100f, side / 100f)
        p.strokeWidth = 6.5f
        accent.strokeWidth = 6f
        when (glyph) {
            Glyph.PHONE -> phone(canvas)
            Glyph.MESSAGES -> messages(canvas)
            Glyph.CHROME -> chrome(canvas)
            Glyph.CAMERA -> camera(canvas)
            Glyph.SETTINGS -> settings(canvas)
            Glyph.GALLERY -> gallery(canvas)
            Glyph.CALCULATOR -> calculator(canvas)
            Glyph.WEATHER -> weather(canvas)
            Glyph.YOUTUBE -> youtube(canvas)
            Glyph.WHATSAPP -> whatsapp(canvas)
            Glyph.SPOTIFY -> spotify(canvas)
            Glyph.TELEGRAM -> telegram(canvas)
            else -> defaultGlyph(canvas)
        }
        canvas.restoreToCount(save)
    }

    private fun phone(c: Canvas) {
        p.color = Color.WHITE
        path.reset()
        path.moveTo(30f, 18f)
        path.cubicTo(24f, 22f, 25f, 38f, 39f, 57f)
        path.cubicTo(54f, 75f, 72f, 79f, 81f, 68f)
        path.lineTo(68f, 53f)
        path.lineTo(56f, 61f)
        path.cubicTo(47f, 56f, 42f, 50f, 38f, 41f)
        path.lineTo(46f, 31f)
        path.close()
        c.drawPath(path, p)
    }

    private fun messages(c: Canvas) {
        p.color = Color.WHITE
        path.reset()
        path.moveTo(19f, 23f); path.quadTo(19f, 15f, 29f, 15f)
        path.lineTo(72f, 15f); path.quadTo(82f, 15f, 82f, 25f)
        path.lineTo(82f, 62f); path.quadTo(82f, 72f, 72f, 72f)
        path.lineTo(43f, 72f); path.lineTo(27f, 84f); path.lineTo(29f, 72f)
        path.quadTo(19f, 70f, 19f, 60f); path.close()
        c.drawPath(path, p)
        fill.color = Color.WHITE
        for (x in listOf(37f, 50f, 63f)) c.drawCircle(x, 44f, 3f, fill)
    }

    private fun chrome(c: Canvas) {
        accent.color = Color.rgb(90, 205, 125)
        c.drawArc(RectF(17f,17f,83f,83f), 210f, 120f, false, accent)
        accent.color = Color.rgb(245, 90, 75)
        c.drawArc(RectF(17f,17f,83f,83f), 330f, 120f, false, accent)
        accent.color = Color.rgb(255, 205, 65)
        c.drawArc(RectF(17f,17f,83f,83f), 90f, 120f, false, accent)
        fill.color = Color.rgb(85, 165, 245)
        c.drawCircle(50f, 50f, 15f, fill)
        p.color = Color.WHITE
        c.drawCircle(50f, 50f, 15f, p)
    }

    private fun camera(c: Canvas) {
        p.color = Color.WHITE
        c.drawRoundRect(RectF(15f,28f,85f,76f), 12f, 12f, p)
        path.reset()
        path.moveTo(31f,28f); path.lineTo(39f,18f); path.lineTo(61f,18f); path.lineTo(69f,28f)
        c.drawPath(path, p)
        c.drawCircle(50f, 52f, 15f, p)
        fill.color = Color.WHITE
        c.drawCircle(50f, 52f, 5f, fill)
    }

    private fun settings(c: Canvas) {
        p.color = Color.WHITE
        c.drawCircle(50f, 50f, 27f, p)
        c.drawCircle(50f, 50f, 10f, p)
        for (i in 0 until 8) {
            val a = Math.toRadians(i * 45.0)
            val x1 = 50f + kotlin.math.cos(a).toFloat() * 31f
            val y1 = 50f + kotlin.math.sin(a).toFloat() * 31f
            val x2 = 50f + kotlin.math.cos(a).toFloat() * 39f
            val y2 = 50f + kotlin.math.sin(a).toFloat() * 39f
            c.drawLine(x1, y1, x2, y2, p)
        }
    }

    private fun gallery(c: Canvas) {
        p.color = Color.WHITE
        c.drawCircle(70f, 29f, 8f, p)
        path.reset()
        path.moveTo(14f, 76f); path.lineTo(37f, 43f); path.lineTo(51f, 60f)
        path.lineTo(62f, 48f); path.lineTo(87f, 77f); path.close()
        c.drawPath(path, p)
        c.drawLine(17f, 82f, 84f, 82f, p)
    }

    private fun calculator(c: Canvas) {
        p.color = Color.WHITE
        c.drawRoundRect(RectF(21f,12f,79f,88f), 9f, 9f, p)
        c.drawRoundRect(RectF(30f,21f,70f,39f), 3f, 3f, p)
        for (row in 0..2) for (col in 0..2) {
            c.drawCircle(34f + col * 16f, 53f + row * 13f, 3f, fill)
        }
    }

    private fun weather(c: Canvas) {
        accent.color = Color.rgb(255, 220, 115)
        c.drawCircle(61f, 35f, 17f, accent)
        for (i in 0 until 8) {
            val a = Math.toRadians(i * 45.0)
            c.drawLine(
                61f + kotlin.math.cos(a).toFloat() * 23f,
                35f + kotlin.math.sin(a).toFloat() * 23f,
                61f + kotlin.math.cos(a).toFloat() * 31f,
                35f + kotlin.math.sin(a).toFloat() * 31f,
                accent
            )
        }
        p.color = Color.WHITE
        path.reset()
        path.moveTo(22f,72f); path.cubicTo(12f,72f,12f,55f,26f,53f)
        path.cubicTo(29f,39f,49f,39f,55f,52f)
        path.cubicTo(73f,45f,86f,59f,81f,72f); path.close()
        c.drawPath(path, p)
    }

    private fun youtube(c: Canvas) {
        p.color = Color.WHITE
        c.drawRoundRect(RectF(14f,27f,86f,73f), 13f, 13f, p)
        path.reset()
        path.moveTo(43f,38f); path.lineTo(65f,50f); path.lineTo(43f,62f); path.close()
        fill.color = Color.WHITE
        c.drawPath(path, fill)
    }

    private fun whatsapp(c: Canvas) {
        p.color = Color.WHITE
        path.reset()
        path.moveTo(50f,15f); path.cubicTo(30f,15f,16f,29f,16f,48f)
        path.cubicTo(16f,58f,20f,66f,26f,72f); path.lineTo(22f,85f)
        path.lineTo(38f,80f); path.cubicTo(59f,88f,83f,72f,84f,49f)
        path.cubicTo(84f,29f,69f,15f,50f,15f); path.close()
        c.drawPath(path, p)
        accent.color = Color.WHITE
        path.reset()
        path.moveTo(39f,34f); path.cubicTo(34f,38f,39f,51f,49f,59f)
        path.cubicTo(58f,66f,68f,65f,70f,58f)
        c.drawPath(path, accent)
    }

    private fun spotify(c: Canvas) {
        accent.color = Color.rgb(120, 225, 160)
        c.drawCircle(50f, 50f, 35f, accent)
        p.color = Color.WHITE
        p.strokeWidth = 5f
        c.drawArc(RectF(27f,31f,74f,61f), 205f, 125f, false, p)
        c.drawArc(RectF(31f,43f,70f,68f), 205f, 125f, false, p)
        c.drawArc(RectF(36f,54f,65f,74f), 205f, 120f, false, p)
    }

    private fun telegram(c: Canvas) {
        accent.color = Color.rgb(105, 190, 250)
        path.reset()
        path.moveTo(13f,47f); path.lineTo(84f,18f); path.lineTo(68f,83f)
        path.lineTo(49f,65f); path.lineTo(38f,76f); path.lineTo(39f,55f); path.close()
        c.drawPath(path, accent)
        p.color = Color.WHITE
        c.drawLine(39f,55f,68f,35f,p)
        c.drawLine(49f,65f,68f,35f,p)
    }

    private fun defaultGlyph(c: Canvas) {
        p.color = Color.WHITE
        c.drawCircle(50f, 50f, 30f, p)
        c.drawLine(32f, 50f, 68f, 50f, p)
        c.drawLine(50f, 32f, 50f, 68f, p)
    }
}
