package com.abood.liquidglassicons

import android.content.ComponentName
import android.content.Intent
import android.view.View
import java.lang.reflect.Field
import java.util.WeakHashMap

internal object IconPackageResolver {
    private data class CacheEntry(val info: Any?, val packageName: String?)
    private val cache = WeakHashMap<View, CacheEntry>()

    @Synchronized
    fun resolve(view: View): String? {
        val info = findFieldValue(view, "mInfo")
        cache[view]?.let { if (it.info === info) return it.packageName }

        val pkg = extractPackage(info)
        cache[view] = CacheEntry(info, pkg)
        return pkg
    }

    private fun extractPackage(info: Any?): String? {
        if (info == null) return null
        var type: Class<*>? = info.javaClass
        while (type != null && type != Any::class.java) {
            for (field in type.declaredFields) {
                try {
                    field.isAccessible = true
                    val value = field.get(info)
                    when (value) {
                        is Intent -> {
                            value.component?.packageName?.let { return it }
                            value.`package`?.let { return it }
                        }
                        is ComponentName -> return value.packageName
                    }
                } catch (_: Throwable) {
                }
            }
            type = type.superclass
        }

        // Some launcher builds expose the target component through a getter instead.
        try {
            val component = info.javaClass.methods.firstOrNull {
                it.name == "getTargetComponent" && it.parameterTypes.isEmpty()
            }?.invoke(info) as? ComponentName
            if (component != null) return component.packageName
        } catch (_: Throwable) {
        }
        return null
    }

    private fun findFieldValue(instance: Any, name: String): Any? {
        var type: Class<*>? = instance.javaClass
        while (type != null && type != Any::class.java) {
            try {
                val field: Field = type.getDeclaredField(name)
                field.isAccessible = true
                return field.get(instance)
            } catch (_: NoSuchFieldException) {
                type = type.superclass
            } catch (_: Throwable) {
                return null
            }
        }
        return null
    }
}
