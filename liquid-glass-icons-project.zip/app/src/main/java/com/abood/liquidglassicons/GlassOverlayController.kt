package com.abood.liquidglassicons

import android.graphics.Color
import android.graphics.Rect
import android.graphics.RectF
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.example.liquidglass.GlassMaterial
import com.example.liquidglass.LiquidGlassView
import java.util.WeakHashMap

internal object GlassOverlayController {
    private const val TAG = "LGIcons"
    private data class Entry(
        val glass: LiquidGlassView,
        val glyph: GlyphView,
        val packageName: String
    )

    private val entries = WeakHashMap<View, Entry>()
    private val pending = WeakHashMap<View, Boolean>()

    @Synchronized
    fun onIconDraw(iconView: View, packageName: String) {
        val existing = entries[iconView]
        if (existing != null && existing.packageName == packageName) {
            updatePosition(iconView, existing)
            return
        }
        if (existing != null) remove(iconView)
        if (pending.put(iconView, true) == true) return
        iconView.post {
            synchronized(this) {
                pending.remove(iconView)
                if (entries.containsKey(iconView)) return@synchronized
                create(iconView, packageName)
            }
        }
    }

    private fun create(iconView: View, packageName: String) {
        try {
            val decor = iconView.rootView as? ViewGroup ?: return
            val content = decor.findViewById<View>(android.R.id.content)
                ?: (decor as? ViewGroup)?.getChildAt(0)
                ?: return
            val context = iconView.context
            val overlay = obtainOverlay(decor, context) ?: return

            val glass = LiquidGlassView(context).apply {
                isClickable = false
                isFocusable = false
                clipChildren = false
                clipToPadding = false
                material = GlassMaterial.CLEAR
                enableBackdropBlur = true
                enableChromaticAberration = true
                enableChromaticDispersion = true
                enableSensorHighlight = false
                // The launcher source is static most of the time. Scroll/layout invalidations
                // refresh it without forcing every glass icon into a permanent render loop.
                enableDynamicBackground = false
                cornerRadius = 18f
                displacementScale = 15f
                blurAmount = 0.11f
                aberrationIntensity = 1.2f
                bevelWidth = 7f
                refractionHeight = 13f
                glassTint = Color.argb(12, 255, 255, 255)
                backdropSource = content
            }
            val glyph = GlyphView(context, GlassIconCatalog.glyph(packageName))
            glass.addView(
                glyph,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            val entry = Entry(glass, glyph, packageName)
            entries[iconView] = entry
            overlay.addView(glass, FrameLayout.LayoutParams(1, 1))
            updatePosition(iconView, entry)
            iconView.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) = Unit
                override fun onViewDetachedFromWindow(v: View) {
                    synchronized(this@GlassOverlayController) {
                        entries.remove(v)?.let { e ->
                            (e.glass.parent as? ViewGroup)?.removeView(e.glass)
                        }
                        pending.remove(v)
                        v.removeOnAttachStateChangeListener(this)
                    }
                }
            })
            Log.i(TAG, "Glass glyph attached for $packageName")
        } catch (t: Throwable) {
            Log.e(TAG, "Unable to create glass icon for $packageName", t)
        }
    }

    private fun obtainOverlay(decor: ViewGroup, context: android.content.Context): FrameLayout? {
        // Keep one transparent, full-window overlay above the stock launcher content.
        for (i in 0 until decor.childCount) {
            val child = decor.getChildAt(i)
            if (child is FrameLayout && child.tag == OVERLAY_TAG) return child
        }
        return try {
            FrameLayout(context).apply {
                tag = OVERLAY_TAG
                clipChildren = false
                clipToPadding = false
                isClickable = false
                isFocusable = false
                setWillNotDraw(true)
            }.also {
                decor.addView(
                    it,
                    ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                it.bringToFront()
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Could not attach window overlay", t)
            null
        }
    }

    @Synchronized
    fun remove(iconView: View) {
        pending.remove(iconView)
        entries.remove(iconView)?.let { entry ->
            (entry.glass.parent as? ViewGroup)?.removeView(entry.glass)
        }
    }

    private fun updatePosition(iconView: View, entry: Entry) {
        val glass = entry.glass
        val parent = glass.parent as? ViewGroup ?: return
        val decor = parent.parent as? ViewGroup ?: return

        val bounds = Rect()
        try {
            var type: Class<*>? = iconView.javaClass
            var method: java.lang.reflect.Method? = null
            while (type != null && method == null) {
                method = try {
                    type.getDeclaredMethod("getIconBounds", Rect::class.java).apply { isAccessible = true }
                } catch (_: NoSuchMethodException) {
                    type = type.superclass
                    null
                }
            }
            method?.invoke(iconView, bounds) ?: throw NoSuchMethodException("getIconBounds(Rect)")
        } catch (_: Throwable) {
            // Fallback: the icon image area is usually the upper square portion of BubbleTextView.
            val side = (iconView.width * 0.68f).toInt().coerceAtLeast(1)
            bounds.set((iconView.width - side) / 2, 0, (iconView.width + side) / 2, side)
        }
        if (bounds.width() <= 0 || bounds.height() <= 0) return

        val location = IntArray(2)
        val decorLocation = IntArray(2)
        iconView.getLocationOnScreen(location)
        decor.getLocationOnScreen(decorLocation)

        val local = RectF(bounds)
        iconView.matrix.mapRect(local)
        val left = (location[0] + local.left - decorLocation[0]).toInt()
        val top = (location[1] + local.top - decorLocation[1]).toInt()
        val width = local.width().toInt().coerceAtLeast(1)
        val height = local.height().toInt().coerceAtLeast(1)

        val lp = glass.layoutParams as? FrameLayout.LayoutParams
            ?: FrameLayout.LayoutParams(width, height)
        val changed = lp.width != width || lp.height != height ||
            lp.leftMargin != left || lp.topMargin != top
        if (changed) {
            lp.width = width
            lp.height = height
            lp.leftMargin = left
            lp.topMargin = top
            glass.layoutParams = lp
            glass.cornerRadius = minOf(width, height) * 0.22f
            glass.bevelWidth = minOf(width, height) * 0.075f
            glass.refractionHeight = minOf(width, height) * 0.14f
            entry.glyph.invalidate()
            glass.invalidate()
        }
    }

    private const val OVERLAY_TAG = "com.abood.liquidglassicons.OVERLAY"
}
