# Liquid Glass Icons — OPPO Launcher module

This is an LSPosed module for the stock OPPO launcher package `com.android.launcher`.

## What it does

- Hooks `com.android.launcher3.BubbleTextView.drawIcon(Canvas)` only.
- Resolves each view's app package from its `mInfo` item.
- Suppresses the stock icon draw for the selected app packages only.
- Places a separate `LiquidGlassView` at that icon's measured `getIconBounds(Rect)` position.
- Uses the stock launcher content as the backdrop source, so each glass surface captures its own region instead of reusing one screen-wide crop.
- Draws original vector glyph artwork inside the glass surface. The launcher itself, icon labels, and click targets remain in place.

The included glyph set covers Phone, Messages, Chrome, Camera, Settings, Gallery, Calculator, Weather, YouTube, WhatsApp, Spotify, and Telegram. Package aliases are listed in `GlassIconCatalog.kt`.

## Build

The project uses Android Gradle Plugin 8.10.0, Kotlin 2.0.21, compile SDK 36, NDK 27.0.12077973, and the included Gradle wrapper.

Build command:

```bash
./gradlew :app:assembleRelease
```

Output:

```text
app/build/outputs/apk/release/app-release-unsigned.apk
```

## Install and activate

1. Install the APK.
2. In LSPosed, enable **Liquid Glass Icons** for `com.android.launcher`.
3. Force-stop the OPPO launcher or reboot.
4. Open the home screen and test one of the selected apps.

This first package is a development build. It has not yet been device-tested on the CPH2781. If the launcher crashes or icons disappear, disable the module in LSPosed to restore the stock launcher rendering.

## Important implementation notes

- The module hooks `drawIcon(Canvas)` rather than `onDraw(Canvas)`, so it does not replace label, badge, or general view drawing.
- Each icon gets an independent glass view and independent bounds. The backdrop source is the launcher content root, not a shared pre-captured bitmap.
- The module intentionally does not install a replacement launcher or use opaque background plates.
- The current first pass uses fixed package aliases. If one app is not affected, its package name on this firmware may differ; check `adb shell pm list packages` and add the exact package to `GlassIconCatalog.kt`.

## Build verification status

The project source and launcher hook were prepared against the uploaded renderer source and `OplusLauncher.apk`. A local Gradle build could not run in this environment because the Gradle distribution host was unreachable, so the APK is **not yet build-verified**. The supplied GitHub Actions workflow downloads Gradle/dependencies and performs the first full build. Treat this as a test build until it has been installed and exercised on the phone.
